import { NextRequest, NextResponse } from "next/server";
import RunwayML from "@runwayml/sdk";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { prompt, imageData, duration = 5, ratio = "2:3" } = body;

    if (!process.env.RUNWAYML_API_SECRET) {
      return NextResponse.json({ error: "RUNWAYML_API_SECRET is not configured." }, { status: 500 });
    }
    if (!prompt || !imageData) {
      return NextResponse.json({ error: "Prompt and a start image are required." }, { status: 400 });
    }

    const client = new RunwayML({ apiKey: process.env.RUNWAYML_API_SECRET });

    const task = await client.imageToVideo.create({
      model: "gen4.5",
      promptImage: imageData,
      promptText: prompt,
      ratio,
      duration: Math.min(Math.max(Number(duration), 5), 10)
    }).waitForTaskOutput();

    const url = task.output?.[0];
    if (!url) throw new Error("Provider returned no video.");
    return NextResponse.json({ url });
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || "Video generation failed." }, { status: 500 });
  }
}