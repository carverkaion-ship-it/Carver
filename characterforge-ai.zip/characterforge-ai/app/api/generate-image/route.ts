import { NextRequest, NextResponse } from "next/server";
import RunwayML from "@runwayml/sdk";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { prompt, ratio = "2:3", referenceImages = [] } = body;

    if (!process.env.RUNWAYML_API_SECRET) {
      return NextResponse.json({ error: "RUNWAYML_API_SECRET is not configured." }, { status: 500 });
    }
    if (!prompt) return NextResponse.json({ error: "Prompt is required." }, { status: 400 });

    const client = new RunwayML({ apiKey: process.env.RUNWAYML_API_SECRET });

    const task = await client.textToImage.create({
      model: "seedream5_pro",
      ratio,
      promptText: prompt,
      referenceImages: referenceImages.slice(0, 10)
    }).waitForTaskOutput();

    const url = task.output?.[0];
    if (!url) throw new Error("Provider returned no image.");
    return NextResponse.json({ url });
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || "Image generation failed." }, { status: 500 });
  }
}