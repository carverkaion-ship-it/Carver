 "use client";

import { useMemo, useState } from "react";

type Ref = { file: File | null; url: string | null };

const emptyRefs = (): Ref[] => Array.from({ length: 3 }, () => ({ file: null, url: null }));

export default function Home() {
  const [refs, setRefs] = useState<Ref[]>(emptyRefs());
  const [prompt, setPrompt] = useState("Create a photorealistic lifestyle photo of the two exact characters looking at each other and smiling naturally. Preserve their facial features, skin tones, body proportions, hairstyles and outfits exactly. Do not redesign, blend, beautify, age, or add tattoos/marks.");
  const [mode, setMode] = useState<"image" | "video">("image");
  const [ratio, setRatio] = useState("2:3");
  const [duration, setDuration] = useState("5");
  const [status, setStatus] = useState("Ready");
  const [output, setOutput] = useState<string | null>(null);
  const [isVideo, setIsVideo] = useState(false);

  const canGenerate = useMemo(() => refs.some(r => r.file) && prompt.trim().length > 0, [refs, prompt]);

  function addRef(index: number, file: File | null) {
    if (!file) return;
    const copy = [...refs];
    if (copy[index].url) URL.revokeObjectURL(copy[index].url);
    copy[index] = { file, url: URL.createObjectURL(file) };
    setRefs(copy);
  }

  async function fileToDataUri(file: File) {
    return await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  async function generate() {
    if (!canGenerate) return;
    setStatus("Generating…");
    setOutput(null);
    setIsVideo(false);

    try {
      const referenceImages = [];
      for (let i = 0; i < refs.length; i++) {
        if (refs[i].file) {
          referenceImages.push({
            uri: await fileToDataUri(refs[i].file!),
            tag: i === 0 ? "female" : i === 1 ? "male" : "pose"
          });
        }
      }

      if (mode === "image") {
        const res = await fetch("/api/generate-image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt, ratio, referenceImages })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Image generation failed");
        setOutput(data.url);
        setStatus("Image complete");
      } else {
        // Use the first uploaded image as the start frame.
        const first = refs.find(r => r.file)?.file;
        if (!first) throw new Error("Upload at least one reference image.");
        const imageData = await fileToDataUri(first);
        const res = await fetch("/api/generate-video", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt, imageData, duration: Number(duration), ratio })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Video generation failed");
        setOutput(data.url);
        setIsVideo(true);
        setStatus("Video complete");
      }
    } catch (e: any) {
      setStatus(e?.message || "Something went wrong");
    }
  }

  return (
    <div className="page">
      <header className="topbar">
        <div className="brand">Character<span>Forge</span> AI</div>
        <div className="nav"><span className="pill">Reference-first</span><span className="pill">Image + Video</span></div>
      </header>

      <main className="main">
        <section className="hero">
          <h1>Make your characters move without losing who they are.</h1>
          <p>Upload character references, lock their identity, describe the scene, and generate photorealistic images or short videos.</p>
        </section>

        <div className="grid">
          <aside className="panel">
            <h2>1. Character references</h2>
            <div className="refs">
              {refs.map((r, i) => (
                <label className="ref" key={i}>
                  {r.url ? <img src={r.url} alt={`Reference ${i + 1}`} /> : <>+<br/>Reference {i + 1}</>}
                  <input type="file" accept="image/png,image/jpeg,image/webp" onChange={e => addRef(i, e.target.files?.[0] || null)} />
                </label>
              ))}
            </div>

            <label className="lock">
              <input type="checkbox" defaultChecked />
              <span><b>Identity Lock</b><br/>Treat uploaded character features, skin tone, body type, face shape, hair and outfit as fixed references.</span>
            </label>

            <div className="field">
              <label className="label">Mode</label>
              <select className="select" value={mode} onChange={e => setMode(e.target.value as "image" | "video")}>
                <option value="image">Image generation</option>
                <option value="video">Image → video</option>
              </select>
            </div>

            <div className="field">
              <label className="label">Aspect ratio</label>
              <select className="select" value={ratio} onChange={e => setRatio(e.target.value)}>
                <option value="2:3">2:3 — Portrait</option>
                <option value="9:16">9:16 — TikTok / Reels</option>
                <option value="1:1">1:1 — Square</option>
                <option value="16:9">16:9 — Landscape</option>
              </select>
            </div>

            {mode === "video" && (
              <div className="field">
                <label className="label">Video duration</label>
                <select className="select" value={duration} onChange={e => setDuration(e.target.value)}>
                  <option value="5">5 seconds</option>
                  <option value="8">8 seconds</option>
                  <option value="10">10 seconds</option>
                </select>
              </div>
            )}

            <div className="field">
              <label className="label">Prompt</label>
              <textarea className="textarea" value={prompt} onChange={e => setPrompt(e.target.value)} />
            </div>

            <div className="actions">
              <button className="btn secondary" onClick={() => { setRefs(emptyRefs()); setOutput(null); setStatus("Ready"); }}>Clear</button>
              <button className="btn primary" disabled={!canGenerate} onClick={generate}>Generate</button>
            </div>
            <div className="tip">Tip: use one clean reference per character and a separate pose/location reference when possible.</div>
          </aside>

          <section className="panel output">
            <div className="outputHead"><h2>2. Result</h2><span className="status">{status}</span></div>
            <div className="canvas">
              {output ? (isVideo ? <video src={output} controls autoPlay loop playsInline /> : <img src={output} alt="Generated result" />) :
                <div className="empty"><strong>Your generation will appear here</strong>Upload references and click Generate.</div>}
            </div>
          </section>
        </div>

        <div className="footer">CharacterForge AI is a starter app. Generation costs are charged by the connected model provider.</div>
      </main>
    </div>
  );
}