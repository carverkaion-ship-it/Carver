import "./globals.css";

export const metadata = {
  title: "CharacterForge AI",
  description: "Reference-first AI image and video generator"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}