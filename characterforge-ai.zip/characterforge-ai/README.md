# CharacterForge AI

A reference-first AI image/video generator starter built with Next.js and the Runway API.

## What it does
- Upload up to 3 reference images.
- Identity-lock prompt behavior.
- Multi-reference image generation.
- Image-to-video generation.
- Portrait, 9:16, square and landscape layouts.
- Server-side API key handling.

## Run locally

1. Install Node.js 18+.
2. Create a Runway Dev account and API key.
3. Copy `.env.example` to `.env.local`.
4. Put your key in `RUNWAYML_API_SECRET`.
5. Run:

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Important production notes

The browser sends reference images as data URIs. Runway documents data-URI limits, so for larger production uploads, add object storage (S3/R2/Supabase Storage) and send HTTPS asset URLs instead.

The current image route uses `seedream5_pro` with multi-reference image support. The video route uses Runway `gen4.5` image-to-video from a single start frame. For stronger multi-reference video consistency, the next production version can use a reference-capable video model/router and a persistent asset library.

Never expose `RUNWAYML_API_SECRET` in client-side code.

Sources:
- Runway API setup: https://docs.dev.runwayml.com/guides/setup/
- Runway image generation: https://docs.dev.runwayml.com/guides/using-the-api/
- Runway image/video API reference: https://docs.dev.runwayml.com/api/
